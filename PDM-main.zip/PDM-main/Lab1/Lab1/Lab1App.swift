import SwiftUI

@main
struct Lab1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
