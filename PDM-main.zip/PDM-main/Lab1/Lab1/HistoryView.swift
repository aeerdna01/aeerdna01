//
//  HistoryView.swift
//  Lab1
//
//  Created by Student @C03 on 26.10.2023.
//

import SwiftUI

struct HistoryView: View {
    var body: some View {
        //@Binding var text 
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    HistoryView()
}
