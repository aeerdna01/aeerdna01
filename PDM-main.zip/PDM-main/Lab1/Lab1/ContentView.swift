import SwiftUI

struct DeviceRotationViewModifier: ViewModifier {
    let action: (UIDeviceOrientation) -> Void

    func body(content: Content) -> some View {
        content
            .onAppear()
            .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
                action(UIDevice.current.orientation)
            }
    }
}

extension View {
    func onRotate(perform action: @escaping (UIDeviceOrientation) -> Void) -> some View {
        self.modifier(DeviceRotationViewModifier(action: action))
    }
}

var history = ""
struct DetailView: View {
     
     let text: String
     var body: some View {
         VStack {
             Text("You entered: ")
             Text(history)
                 .onAppear{
                     history = history + text
                 }
             Text(text)
             
         }
         .navigationTitle("History")
     }
}

extension Color {
    init(hex: UInt, alpha: Double = 1) {
        self.init(
            .sRGB,
            red: Double((hex >> 16) & 0xff) / 255,
            green: Double((hex >> 08) & 0xff) / 255,
            blue: Double((hex >> 00) & 0xff) / 255,
            opacity: alpha
        )
    }
}

struct ContentView: View {
    @State private var text_input: String = ""
    @State private var text_display: String = ""
    @State private var orientation = UIDeviceOrientation.portrait



    var body: some View {
        Group{
            if self.orientation.isPortrait{
                NavigationStack {
                    VStack (alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                        Image(systemName: "leaf")
                            .imageScale(.large)
                            .foregroundStyle(Color(hex: 0xE4C06C, alpha: 0.9))
                            .padding()
                        
        
                        
                        Text("PDM")
                            .font(.title)
                            .fontWeight(.heavy)
                            .foregroundStyle(Color(hex: 0xE4C06C, alpha: 0.9))
                            
                        Text("Laborator")
                            .font(.title)
                            .italic()
                            .foregroundStyle(Color(hex: 0xE4C06C, alpha: 0.9))
                        
                        
                        TextField("Enter text: ", text:$text_input)
                            .padding()
                            .border(Color(hex: 0xE4C06C, alpha: 0.9))
                            .foregroundStyle(Color(hex: 0xE4C06C, alpha: 0.9))
                        
                        Button(action: {
                            text_display = text_input
                        }) {
                            Text("Show text ")
                                .font(.title)
                                .padding()
                                .frame(width: 200)
                                .fontWeight(.heavy)
                                .foregroundColor(Color(hex: 0x023020, alpha: 0.9))
                                .background(Color(hex: 0xE4C06C, alpha: 0.9))
                                .cornerRadius(25)
                        }
                        ScrollView(.vertical){
                            Text("You entered: \(text_display)")
                                .padding()
                                .scrollDisabled(false)
                                .border(Color(hex: 0xE4C06C, alpha: 0.9))
                                .foregroundStyle(Color(hex: 0xE4C06C, alpha: 0.9))
                        }
                        .padding()
                        .frame(height: 200)
                        
                        Button(action: {
                            text_display = ""
                        }){
                            Text("Delete text")
                                .font(.title)
                                .padding()
                                .frame(width: 200)
                                .fontWeight(.heavy)
                                .foregroundColor(Color(hex: 0x023020, alpha: 0.9))
                                .background(Color(hex: 0xE4C06C, alpha: 0.9))
                                .cornerRadius(25)
                        }
                        
    
                        
                        NavigationLink("Show history", value: text_input)
                            .navigationDestination(for: String.self) { textValue in
                                DetailView(text: text_input)
                            }
                            .font(.title)
                            .padding()
                            .frame(width: 300)
                            .fontWeight(.heavy)
                            .foregroundColor(Color(hex: 0x023020, alpha: 0.9))
                            .background(Color(hex: 0xE4C06C, alpha: 0.9))
                            .cornerRadius(25)
                        
                        
                    }
                    .padding()
                    .frame(minWidth: 0, maxWidth:.infinity, minHeight: 0, maxHeight: .infinity)
                    .background(Color(hex: 0x023020, alpha: 0.9))
                }
            }
            else if self.orientation.isLandscape{
                NavigationStack{
                    HStack (alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                        
                        Image(systemName: "globe")
                            .imageScale(.large)
                            .foregroundStyle(.tint)
                        Text("PDM")
                            .font(.title)
                        Text("Laborator1")
                            .font(.title)
                            .fontWeight(.bold)
                        
                        
                        TextField("Enter text: ", text:$text_input)
                            .padding()
                        Button(action: {
                            text_display = text_input
                        }) {
                            Text("Show text ")
                                .font(.title)
                                .padding()
                                .frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: .infinity)
                                .foregroundColor(Color.black)
                                .background(Color.gray)
                                .cornerRadius(25)
                        }
                        ScrollView(.vertical){
                            Text("You entered: \(text_display)")
                                .padding()
                                .scrollDisabled(false)
                        }
                        .padding()
                        .frame(height: 200)
                        
                        Button(action: {
                            text_display = ""
                        }){
                            Text("Delete text")
                                .font(.title)
                                .padding()
                                .frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: .infinity)
                                .foregroundColor(Color.black)
                                .background(Color.gray)
                                .cornerRadius(25)
                        }
                    }
                    .padding()
                    .frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth:.infinity, minHeight: 0, maxHeight: .infinity)
                    
                    List {
                        NavigationLink("Show history", value: text_input)
                    }
                    .navigationDestination(for: String.self) { textValue in
                        DetailView(text: text_input)
                    }
                    .padding(100)                }
            }
            else if orientation.isFlat {
                Text("Flat")
            }
            else {
                Text("Unkown")
            }
        }
        .onRotate { newOrientation in
            orientation = newOrientation
        }
    }
       
}

/*
//Laborator 1 - Tutorial Hello World
struct ContentView: View {
    var body: some View {
        VStack (alignment: .leading) {
            Text("PDM")
                .font( .title)
            HStack {
                Text("Joshua Tree National Park")
                    .font(.subheadline)
                Spacer()
                Text("California")
                    .font(.subheadline)
            }
        }
        .padding()
    }
}
*/
#Preview {
    ContentView()
}
